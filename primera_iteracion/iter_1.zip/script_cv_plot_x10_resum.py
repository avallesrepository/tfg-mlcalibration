import openml
import pandas as pd
import numpy as np
import os
import json
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss
from sklearn.preprocessing import LabelEncoder
from sklearn.impute import SimpleImputer
from betacal import BetaCalibration
from netcal.binning import BBQ
from venn_abers import VennAbersCalibrator
import calibration as cal  # Para calcular ECE

# Crear directorio para guardar resultados y gráficos
output_dir = "calibration_results_simplified"
os.makedirs(output_dir, exist_ok=True)

# Carga de datasets
dataset_ids = [15, 31, 37, 44]

# Función para guardar gráficos comparativos
def save_combined_calibration_plot(dataset_id, calibration_results, y_test):
    plt.figure(figsize=(10, 8))
    
    for method, prob in calibration_results.items():
        prob_true, prob_pred = calibration_curve(y_test, prob, n_bins=10)
        plt.plot(prob_pred, prob_true, marker='o', label=method)
    
    plt.plot([0, 1], [0, 1], "k--", label="Perfectly Calibrated")
    plt.xlabel("Mean Predicted Probability")
    plt.ylabel("Fraction of Positives")
    plt.title(f"Calibration Curves Comparison (Dataset {dataset_id})")
    plt.legend(loc="best")
    
    plot_file = os.path.join(output_dir, f"calibration_curves_dataset_{dataset_id}.png")
    plt.savefig(plot_file)
    plt.close()

# Función principal para evaluaciones simplificadas
def evaluate_with_repeated_cv(dataset_id, n_splits=5, n_repeats=10):
    dataset = openml.datasets.get_dataset(dataset_id)
    X, y, _, _ = dataset.get_data(target=dataset.default_target_attribute)

    le = LabelEncoder()
    y = le.fit_transform(y)
    X = pd.DataFrame(X)
    X = pd.get_dummies(X)
    imputer = SimpleImputer(strategy='mean')
    X = imputer.fit_transform(X)

    all_metrics = {method: {"Accuracy": [], "Brier Score": [], "Log Loss": [], "ECE": []} 
                   for method in ["Base Model", "Platt Scaling", "Isotonic Regression", 
                                  "Beta Calibration", "BBQ", "Venn-Abers"]}
    all_probabilities = {method: [] for method in all_metrics.keys()}
    y_true_all = []

    for repetition in range(n_repeats):
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=repetition)
        
        for train_idx, test_idx in skf.split(X, y):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]
            y_true_all.extend(y_test)

            clf = LogisticRegression(random_state=42, max_iter=8000)
            clf.fit(X_train, y_train)
            prob_test = clf.predict_proba(X_test)[:, 1]
            pred_test = (prob_test > 0.5).astype(int)

            all_metrics["Base Model"]["Accuracy"].append(accuracy_score(y_test, pred_test))
            all_metrics["Base Model"]["Brier Score"].append(brier_score_loss(y_test, prob_test))
            all_metrics["Base Model"]["Log Loss"].append(log_loss(y_test, prob_test))
            all_metrics["Base Model"]["ECE"].append(cal.get_calibration_error(prob_test, y_test))
            all_probabilities["Base Model"].extend(prob_test)

            platt_clf = CalibratedClassifierCV(estimator=clf, method="sigmoid", cv="prefit")
            platt_clf.fit(X_train, y_train)
            prob_platt = platt_clf.predict_proba(X_test)[:, 1]
            all_metrics["Platt Scaling"]["Accuracy"].append(accuracy_score(y_test, (prob_platt > 0.5).astype(int)))
            all_metrics["Platt Scaling"]["Brier Score"].append(brier_score_loss(y_test, prob_platt))
            all_metrics["Platt Scaling"]["Log Loss"].append(log_loss(y_test, prob_platt))
            all_metrics["Platt Scaling"]["ECE"].append(cal.get_calibration_error(prob_platt, y_test))
            all_probabilities["Platt Scaling"].extend(prob_platt)

            isotonic_clf = CalibratedClassifierCV(estimator=clf, method="isotonic", cv="prefit")
            isotonic_clf.fit(X_train, y_train)
            prob_isotonic = isotonic_clf.predict_proba(X_test)[:, 1]
            all_metrics["Isotonic Regression"]["Accuracy"].append(accuracy_score(y_test, (prob_isotonic > 0.5).astype(int)))
            all_metrics["Isotonic Regression"]["Brier Score"].append(brier_score_loss(y_test, prob_isotonic))
            all_metrics["Isotonic Regression"]["Log Loss"].append(log_loss(y_test, prob_isotonic))
            all_metrics["Isotonic Regression"]["ECE"].append(cal.get_calibration_error(prob_isotonic, y_test))
            all_probabilities["Isotonic Regression"].extend(prob_isotonic)

            beta_clf = BetaCalibration()
            beta_clf.fit(prob_test, y_test)
            prob_beta = beta_clf.predict(prob_test)
            all_metrics["Beta Calibration"]["Accuracy"].append(accuracy_score(y_test, (prob_beta > 0.5).astype(int)))
            all_metrics["Beta Calibration"]["Brier Score"].append(brier_score_loss(y_test, prob_beta))
            all_metrics["Beta Calibration"]["Log Loss"].append(log_loss(y_test, prob_beta))
            all_metrics["Beta Calibration"]["ECE"].append(cal.get_calibration_error(prob_beta, y_test))
            all_probabilities["Beta Calibration"].extend(prob_beta)

            bbq_clf = BBQ()
            bbq_clf.fit(prob_test, y_test)
            prob_bbq = bbq_clf.transform(prob_test)
            all_metrics["BBQ"]["Accuracy"].append(accuracy_score(y_test, (prob_bbq > 0.5).astype(int)))
            all_metrics["BBQ"]["Brier Score"].append(brier_score_loss(y_test, prob_bbq))
            all_metrics["BBQ"]["Log Loss"].append(log_loss(y_test, prob_bbq))
            all_metrics["BBQ"]["ECE"].append(cal.get_calibration_error(prob_bbq, y_test))
            all_probabilities["BBQ"].extend(prob_bbq)

            va_clf = VennAbersCalibrator(estimator=clf)
            va_clf.fit(prob_test, y_test)
            prob_va = va_clf.predict_proba(X_test)[:, 1]
            all_metrics["Venn-Abers"]["Accuracy"].append(accuracy_score(y_test, (prob_va > 0.5).astype(int)))
            all_metrics["Venn-Abers"]["Brier Score"].append(brier_score_loss(y_test, prob_va))
            all_metrics["Venn-Abers"]["Log Loss"].append(log_loss(y_test, prob_va))
            all_metrics["Venn-Abers"]["ECE"].append(cal.get_calibration_error(prob_va, y_test))
            all_probabilities["Venn-Abers"].extend(prob_va)

    # Promediar métricas de las repeticiones
    final_metrics = {
        method: {metric: np.mean(all_metrics[method][metric]) for metric in all_metrics[method].keys()}
        for method in all_metrics.keys()
    }

    # Crear gráfico combinado con probabilidades acumuladas
    save_combined_calibration_plot(dataset_id, all_probabilities, np.array(y_true_all))

    # Guardar métricas en archivo JSON
    metrics_file = os.path.join(output_dir, f"metrics_dataset_{dataset_id}_simplified.json")
    with open(metrics_file, "w") as f:
        json.dump(final_metrics, f, indent=4)
    print(f"Métricas para dataset {dataset_id} guardadas en {metrics_file}")

# Evaluar en todos los datasets
for dataset_id in dataset_ids:
    print(f"\nEvaluando con repeticiones simplificadas en dataset {dataset_id}...\n")
    evaluate_with_repeated_cv(dataset_id)
